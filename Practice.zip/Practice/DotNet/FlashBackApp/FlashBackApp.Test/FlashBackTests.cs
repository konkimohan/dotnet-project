﻿using NUnit.Framework;

namespace FlashBackApp.Test
{
    /// <summary>
    /// Test class for <see cref="FlashBack"/>
    /// </summary>
    [TestFixture]
    public class FlashBackTests
    {
        private FlashBack GetInstance()
        {
            return new FlashBack();
        }

        [TestCase(9)]
        [TestCase(27)]
        [TestCase(21)]
        public void TestFlash(int number)
        {
            FlashBack flashBack = GetInstance();
            Assert.AreEqual("Flash", flashBack.Print(number));
        }

        [TestCase(5)]
        [TestCase(10)]
        [TestCase(20)]
        public void TestBack(int number)
        {
            FlashBack flashBack = GetInstance();
            Assert.AreEqual("Back", flashBack.Print(number));
        }

        [TestCase(15)]
        [TestCase(45)]
        [TestCase(75)]
        public void TestFlashBack(int number)
        {
            FlashBack flashBack = GetInstance();
            Assert.AreEqual("Flash Back", flashBack.Print(number));
        }
    }
}
