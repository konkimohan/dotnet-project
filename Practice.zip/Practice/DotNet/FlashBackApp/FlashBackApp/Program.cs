﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FlashBackApp
{
    public class Program
    {
        public static void Main(string[] args)
        {
            Console.WriteLine("Please provide a number which is divisible by 3 or 5 or divisible by both 3 and 5");
            Console.WriteLine("if divisible by 3, prints Flash");
            Console.WriteLine("if divisible by 5, prints Back");
            Console.WriteLine("if divisible by both 3 and 5, prints Flash Back");
            string inputValue = Console.ReadLine();
            if (int.TryParse(inputValue, out int input))
            {
                FlashBack flashBack = new FlashBack();
                Console.WriteLine(flashBack.Print(input));
            }
            else
            {
                Console.WriteLine("Please provide valid interger number!!");
            }

            Console.ReadLine();
        }
    }
}
