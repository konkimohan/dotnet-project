﻿using System;

namespace FlashBackApp
{
    /// <summary>
    /// FlashBack class
    /// </summary>
    public class FlashBack
    {
        /// <summary>
        /// Checks can application Prints Flash, if the number is divisible by 3.
        /// </summary>
        /// <param name="number">given number</param>
        private bool CanPrintFlash(int number)
        {
            if (number % 3 == 0)
            {
                return true;
            }

            return false;
        }

        /// <summary>
        /// Checks can application Prints Back, if the number is divisible by 5.
        /// </summary>
        /// <param name="number">given number</param>
        private bool CanPrintBack(int number)
        {
            if (number % 5 == 0)
                return true;

            return false;
        }

        /// <summary>
        /// Checks can application Prints FlashBack, if the number is divisible by both 3 and 5.
        /// </summary>
        /// <param name="number">given number</param>
        private bool CanPrintFlashBack(int number)
        {
            if (CanPrintBack(number) && CanPrintFlash(number))
                return true;

            return false;
        }

        /// <summary>
        /// Prints Flash or Back or Flash Back based on the input.
        /// if divisible by 3, prints Flash
        /// if dividible by 5, prints Back
        /// if divisble by 3 and 5, prints Flash Back
        /// </summary>
        /// <param name="number"></param>
        public string Print(int number)
        {
            if (CanPrintFlashBack(number))
            {
                return "Flash Back";
            }
            else if (CanPrintBack(number))
            {
                return "Back";
            }
            else if (CanPrintFlash(number))
            {
                return "Flash";
            }
            else
            {
                return "Invalid input, Cannot print Flash or Back or Flash Back";
            }
        }
    }
}
